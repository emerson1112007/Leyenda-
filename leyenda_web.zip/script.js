function verCapitulos(id) {
  const seccion = document.getElementById(id);
  if (seccion.style.display === "none") {
    seccion.style.display = "block";
  } else {
    seccion.style.display = "none";
  }
}

// Buscador
const buscador = document.getElementById('buscador');
buscador.addEventListener('input', function () {
  const manhwas = document.querySelectorAll('.manhwa');
  const texto = buscador.value.toLowerCase();
  manhwas.forEach(m => {
    if (m.innerText.toLowerCase().includes(texto)) {
      m.style.display = 'block';
    } else {
      m.style.display = 'none';
    }
  });
});
